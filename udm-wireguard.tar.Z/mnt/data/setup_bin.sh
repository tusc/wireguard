#!/bin/sh
# https://github.com/tusc/wireguard
# June 14,2020
#
# This script need to be executed after a reboot in order to create
# symlinks under /bin and /etc. There's no harm in rerunning the
# script if the links already exist.

if [ ! -f /bin/bash ]; then
   echo "Creating binary symlinks"
   ln -s /mnt/data/bin/bash /bin/bash &>/dev/null
   ln -s /mnt/data/bin/boringtun /bin/boringtun &>/dev/null
   ln -s /mnt/data/bin/htop /bin/htop &>/dev/null
   ln -s /mnt/data/bin/iftop /bin/iftop &>/dev/null
   ln -s /mnt/data/bin/iperf3 /bin/iperf3 &>/dev/null
   ln -s /mnt/data/bin/wg /bin/wg &>/dev/null
   ln -s /mnt/data/bin/wg-quick /bin/wg-quick &>/dev/null
fi

if [ ! -d /etc/wireguard ]; then
    echo "Creating wireguard directory symlink"
    ln -s /mnt/data/wireguard /etc/wireguard &>/dev/null
fi

# setup file descriptor directory since it's used by the wg-quick script
if [ ! -d /dev/fd ]; then
    echo "Creating file descriptor directory symlink"
    ln -s /proc/self/fd /dev/fd &>/dev/null
fi
